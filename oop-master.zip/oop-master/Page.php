<?php


class Page
{
    public static function PrintHeader()
    {
        echo '<h1>Friss cikkek</h1>';
    }
}