<?php
include "header.php";
include "nav.php";
?>

<?php
include "footer.php";
?>